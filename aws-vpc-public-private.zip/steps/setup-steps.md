# Setup Steps

1. Created VPC (10.0.0.0/16)
2. Created Public Subnet (10.0.1.0/24)
3. Created Private Subnet (10.0.2.0/24)
4. Attached Internet Gateway
5. Configured Route Tables
6. Created NAT Gateway
7. Launched EC2 instances
8. Configured Bastion Host
9. Created S3 Gateway VPC Endpoint
10. Attached IAM Role to Private EC2
