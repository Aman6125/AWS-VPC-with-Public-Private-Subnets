# AWS VPC – Public & Private Subnet Architecture

## 📌 Project Overview
This project demonstrates a real-world AWS networking architecture with:
- Custom VPC
- Public and Private Subnets
- Internet Gateway
- NAT Gateway
- Bastion Host
- S3 Gateway VPC Endpoint

## 🏗 Architecture
![Architecture](architecture/vpc-architecture.png)

## 🔁 Traffic Flow
- Internet → Public EC2 (via Internet Gateway)
- Private EC2 → Internet (via NAT Gateway)
- Private EC2 → Amazon S3 (via VPC Endpoint)

## 🔐 Security Design
- Private EC2 has no public IP
- Access via Bastion Host only
- IAM Role used for S3 access (no access keys)

## 🎯 Learning Outcome
- AWS VPC networking
- Secure cloud architecture
- Bastion host pattern
